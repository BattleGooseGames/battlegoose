# Web-Examples
Examples of Bootstrap-based web templating

This respository is intended to store simple navigation and page layout structures for the kickoff of the Battle Goose Games website.

Here are some resources to get you started with Bootstrap:
https://getbootstrap.com/docs/5.0/getting-started/introduction/

After we get you up and running with this, then we'll move on to Angular when you get more comfortable with Class and Object-Oriented structures in your code.

Let me know if you have any questions about this and I can help, buddy. - Corban

k - wilson